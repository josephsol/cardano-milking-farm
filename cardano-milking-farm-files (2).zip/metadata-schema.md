# Milk Log Metadata Schema

This schema is designed to guide logging of milk production data for blockchain transparency.

## Fields

- `date`: ISO date format (YYYY-MM-DD)
- `liters_produced`: Amount of milk in liters (integer or float)
- `buyer`: Name of buyer (string)
- `payment_method`: "Cash" or "ADA"
- `price_per_liter`: Amount in local currency or ADA
