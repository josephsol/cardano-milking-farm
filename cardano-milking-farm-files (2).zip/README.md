# Cardano Milking Farm – Arsi Huruta 🇪🇹

A Catalyst Fund14 project aiming to improve milk supply in Arsi Huruta, Ethiopia, through a modern milking farm powered by blockchain transparency and local innovation.

## 🌍 Project Summary

We’re setting up a small, modern dairy farm using:
- Improved cow breeds
- Milking machines
- Local labor
- Blockchain logging of milk production and sales data on Cardano

Our goal is to increase milk supply, create jobs, improve transparency, and educate rural communities about blockchain.

## 📦 Project Components

- 🐄 Improved dairy cows (3–5)
- 🧰 Milking machine & tools
- 🛖 Shelter & feeding system
- 👨🏽‍🌾 3–5 hired workers from the local area
- 📊 Daily milk production recorded on-chain
- ₳ ADA accepted as payment (pilot)
- 🧾 Templates for logging milk data on Cardano (coming soon)

## 🔓 Open Source

All outputs will be published here, including:
- Metadata schemas for milk records
- Sample blockchain logging formats
- Educational tutorials and videos
- Monthly progress updates and reports

## 💡 Vision

We aim to create a replicable model for agricultural blockchain use in rural Africa and help the Cardano ecosystem grow at the grassroots level.

---

📍 **Location**: Arsi Huruta, Oromia Region, Ethiopia  
🧑🏽‍🔧 **Lead**: Yosef Solomon (Electrical Engineering student, Catalyst member)

## 📆 Timeline

The project runs for 6 months and includes setup, production, community engagement, and final reporting.

---

🌱 Powered by Cardano | Funded by Project Catalyst | Local-first. Open-source. Impact-driven.
